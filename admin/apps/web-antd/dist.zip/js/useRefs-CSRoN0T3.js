import{bP as o,L as r}from"../jse/index-index-B7giU1sC.js";const f=()=>{const e=r(new Map),s=t=>a=>{e.value.set(t,a)};return o(()=>{e.value=new Map}),[s,e]};export{f as u};
