import{aO as a}from"./bootstrap-BQM3T9kF.js";import{ah as o,aD as t}from"../jse/index-index-B7giU1sC.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
