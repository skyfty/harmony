import{aT as a}from"./bootstrap-Dm3CaSol.js";import{ah as o,aD as t}from"../jse/index-index-DsbfWiij.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
