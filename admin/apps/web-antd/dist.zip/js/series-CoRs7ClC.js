import{a3 as e,an as s,ay as a}from"../jse/index-index-DsbfWiij.js";const t={class:"p-5"},_=e({__name:"series",setup(n){return(o,c)=>(s(),a("div",t,"资源系列页面（已移动）"))}});export{_ as default};
