import{a9 as t,aD as s}from"../jse/index-index-DsbfWiij.js";function r(a){const e=s();return t(()=>{e.value=a()},{flush:"sync"}),e}export{r as e};
