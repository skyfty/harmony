import{a2 as e,an as a,ay as t}from"../jse/index-index-B7giU1sC.js";const s={class:"p-5"},r=e({__name:"tags",setup(n){return(o,c)=>(a(),t("div",s,"资源标签页面（已移动）"))}});export{r as default};
